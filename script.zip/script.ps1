﻿while($true) {
Start-Transcript -path "C:\logging.log" -Force 
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 -bor [Net.SecurityProtocolType]::Tls11 -bor [Net.SecurityProtocolType]::Tls


function Write-Log($string)
{
    $dateTimeNow = Get-Date -Format "dd.MM.yyyy - HH:mm:ss"
    $outStr = "" + $dateTimeNow +" "+$string
 
	Write-Output $outStr 
    
}


$script = "C:\script.ps1"
$serviceName = "WebAppCheck"
$IISFeatures = "Web-WebServer","Web-Common-Http","Web-Default-Doc","Web-Dir-Browsing","Web-Http-Errors","Web-Static-Content","Web-Http-Redirect","Web-Health","Web-Http-Logging","Web-Custom-Logging","Web-Log-Libraries","Web-ODBC-Logging","Web-Request-Monitor","Web-Http-Tracing","Web-Performance","Web-Stat-Compression","Web-Security","Web-Filtering","Web-Basic-Auth","Web-Client-Auth","Web-Digest-Auth","Web-Cert-Auth","Web-IP-Security","Web-Windows-Auth","Web-App-Dev","Web-Net-Ext","Web-Net-Ext45","Web-Asp-Net","Web-Asp-Net45","Web-ISAPI-Ext","Web-ISAPI-Filter","Web-Mgmt-Tools","Web-Mgmt-Console"
$IISSite = "website.local"
$WebDir = "$env:systemdrive\inetpub\wwwroot"
$WebAppDir = "$env:systemdrive\inetpub\wwwroot\webapp"
$GitRepo = "https://github.com/TargetProcess/DevOpsTaskJunior.git"
$URL = "http://localhost/TestApp"
#Webhook Slack
$SlackChannelUri = "https://hooks.slack.com/services/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"
$BodyTemplate = @"
    {
        "username": "Web Bot",
        "text": "WebApp ok \nTime: DATETIME.",
        "icon_emoji":":ghost:"
    }
"@
$body = $BodyTemplate.Replace("DATETIME",$(Get-Date))

#Install Chocolatey
if ( -not (Test-Path -Path "$env:systemdrive\ProgramData\chocolatey")) {
  "Install Chocolatey"
  Set-ExecutionPolicy Bypass -Scope Process -Force; iwr https://chocolatey.org/install.ps1 -UseBasicParsing | iex
  }

#Install Git 
if ( -not (Test-Path -Path "$env:systemdrive\Program Files\Git\")) {
  choco install -y git
  }

#Install nssm
if ((Get-Command -Name 'nssm' -ErrorAction SilentlyContinue -WarningAction SilentlyContinue) -eq $null){
  "Install nssm"
  choco install -y NSSM
  }  

#Create WebCheckApp service
if ((Get-Service -Name $serviceName -ErrorAction SilentlyContinue -WarningAction SilentlyContinue) -eq $null){ 
  $powershell = (Get-Command powershell).Source
  $scriptPath = "C:\script.ps1"
  $arguments = '-ExecutionPolicy Bypass -NoProfile -File "{0}"' -f $scriptPath
  nssm install $serviceName $powershell $arguments
  nssm status $serviceName
  }

#Install PowerShell 5.1
if( -not ($PSVersionTable.PSVersion.Major -ge 5 -and $PSVersionTable.PSVersion.Minor -ge 1)){
  "Install PowerShell 5.1"
  $Source = 'https://download.microsoft.com/download/6/F/5/6F5FF66C-6775-42B0-86C4-47D41F2DA187/Win8.1AndW2K12R2-KB3191564-x64.msu'
  $destination = Join-Path $env:TEMP -ChildPath Win8.1AndW2K12R2-KB3191564-x64.msu
  Set-ExecutionPolicy RemoteSigned
  Invoke-WebRequest -Uri $Source -OutFile $destination -UseBasicParsing 
  Start-Process -FilePath wusa.exe -Wait -ArgumentList "$destination /quiet"
}

#Install posh-git
if (-not (Get-Module -ListAvailable -Name posh-git)) {
  "Install posh-git"
  Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force
  Install-Module -Name posh-git -Force
  Import-Module posh-git
  }

 #Create Firewall rule
if ((Get-NetFirewallRule -DisplayName "Web Port 80" -ErrorAction SilentlyContinue -WarningAction SilentlyContinue) -eq $null) {
  "Create Firewall rule"
  New-NetFirewallRule -DisplayName "Web Port 80" -Direction Inbound -LocalPort 80 -Protocol TCP -Action Allow
  }


"===== Check IIS role ====="
if (-not (Get-WindowsFeature -Name Web-Server).Installed) {
  Install-WindowsFeature -name $IISFeatures -IncludeManagementTools
  Restart-Computer -Force 
  }
else { "OK" }

Import-Module WebAdministration

if (Get-website -Name "Default Web Site") {
  Remove-WebSite -Name "Default Web Site"
  }

"===== Check IIS service ====="
iisreset /start

"===== Check & Update WebApp ====="
if (-not (Test-Path -Path $WebAppDir)){
  New-Item -ItemType directory -Path $WebAppDir
  git clone $GitRepo $WebAppDir 2>&1 | write-host -foregroundColor "green"
  }
else { 
  cd $WebAppDir
  git pull
  "OK" 
  }

#Edit Web.config
(Get-Content "C:\inetpub\wwwroot\webapp\Web.config") -replace '<system.web.>','<system.web>' | Set-content -path "C:\inetpub\wwwroot\webapp\Web.config"
(Get-Content "C:\inetpub\wwwroot\webapp\Web.config") -replace '<compilation targetFramework="4.5.2" />','<compilation targetFramework="4.0" />' | Set-content -path "C:\inetpub\wwwroot\webapp\Web.config"
(Get-Content "C:\inetpub\wwwroot\webapp\Web.config") -replace '<httpRuntime targetFramework="4.5.2" />','<httpRuntime targetFramework="4.0" />' | Set-content -path "C:\inetpub\wwwroot\webapp\Web.config"



"===== Check IIS site ====="
if (-not (Get-website -Name $IISSite)) {
  New-WebSite -Name $IISSite -Port 80 -PhysicalPath $WebDir
  }
else { "OK" }
if ((Get-website -Name $IISSite).Start) {
  Start-WebSite -Name $IISSite
  }
else { "OK" }

"===== Check IIS AppPool ====="
if (-not (Get-WebApplication -Site $IISSite)) {
  New-WebAppPool $IISSite
  New-WebApplication -Name "TestApp" -Site $IISSite -PhysicalPath $WebAppDir -ApplicationPool $IISSite
  }
else { "OK" }

"===== HTTP Request ====="
#Get HTTP code and description
$httpcode = (Invoke-WebRequest -Uri $URL -UseBasicParsing).StatusCode
$statuscodedesc = (Invoke-WebRequest -Uri $URL -UseBasicParsing).StatusDescription
[string]$slack = if (((Invoke-WebRequest -Uri $URL -UseBasicParsing).StatusCode) -eq 200) { Invoke-RestMethod -Uri $SlackChannelUri -Method Post -body $body -ContentType 'application/json' }
if ("$slack" -eq "ok") {
  Write-Host "$statuscodedesc" "$httpcode" -foregroundColor "green" }

Stop-Transcript
Start-Sleep –Seconds 600 
}
